
This resource pack is texturepack compatible, which means if you have other texturepacks installed, its textures will also display in the 3D models of this pack.

The supported contents that change with texturepack are the following:
- water_still
- lava_still
- snow
- cod
- salmon
- cooked_salmon
- pufferfish
- axolotl


Optifine is NOT required for this pack to work, but if Optifine is enabled it also adds the following extras (making sure custom items and emissive textures are enabled):

- The lava glows in the bucket of lava (also texturepack compatible) (NOTE: not compatible with other Optifine packs that have glowing textures, if you prefer other packs to glow place this pack below them)

- Bucket of tropical fish changes depending on the variant you caught (only with one of the 22 canon names, shown in the chart in this pack's folder)

- Bucket of axolotl changes depending on the variant you caught and whether it's baby (also texturepack compatible)

- Renaming a tropical fish item to one of the 22 canon Java names (check the chart in this pack's folder) changes its appearance to its respective variant


(Feel free to give any feedback at https://dragonita-arboth.tumblr.com/ and https://www.curseforge.com/members/findrek_/projects)